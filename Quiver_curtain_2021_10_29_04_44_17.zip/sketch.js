var NOISE_SCALE = 0.004;
var STEP = 30;
var count;

function setup() {
  createCanvas (800, 400);
  strokeWeight(.9);
  noFill();
  count = round(width*2.5/STEP);
  background(255);
}

function drawPerlinCurve ( x, y, phase, step, count, myColour) {
  push();
  stroke(myColour);
  beginShape();
  for (var i=1; i<count; i++) {
    curveVertex(x, y);
    var angle = 2*PI*noise(x* NOISE_SCALE, y* NOISE_SCALE, phase* NOISE_SCALE);
    x += cos(angle)*step;
    y += sin(angle)*step;
  }
  endShape();
  pop();
}

function draw() {
  //background(155);
push();
fill(355,86);
rect(0,0,width, height);
pop();
 

var phase = frameCount / 1;

  for (var y = 0; y < height; y+=10) {
    var myColour = lerpColor(color(98,71,93), color(150, 175, 75), y / height);
    drawPerlinCurve(width+70, y, phase, STEP, count, myColour);
   

  }
}